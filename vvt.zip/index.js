{
  "name": "fft-arel",
  "version": "1.0.0",
  "description": "FFT BOT IG ",
  "main": "index.js",
  "dependencies": {
    "chalk": "^4.1.0",
    "delay": "^4.4.0",
    "inquirer": "^7.3.0",
    "instagram-id-to-url-segment": "^0.0.0",
    "instagram-private-api": "^1.41.0",
    "readline-sync": "^1.4.10"
  },
  "devDependencies": {},
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "AREL TIYAN",
  "license": "ISC"
}
